(function() {
    "use strict";

    document.addEventListener("DOMContentLoaded", function() {

        // CAMPO DATOS USUARIOS
        var nombre = document.getElementById("nombre");
        var apellido = document.getElementById("apellido");
        var email = document.getElementById("email");





    }); // DOM CONTENT LOADED

})();